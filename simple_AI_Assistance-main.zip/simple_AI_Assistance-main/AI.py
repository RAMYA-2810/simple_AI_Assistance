import datetime
import os
import sys
import time
import webbrowser
import pyautogui
import pyttsx3
import speech_recognition as sr

# --- Configuration ---
# You can externalize this into a config.ini file for larger projects
ASSISTANT_NAME = "Jarvis" # Or any name you prefer for the assistant
USER_NAME = "Pugazh"
# Set preferred voice index based on your system's available voices
# Check available voices by running a small script like:
# engine = pyttsx3.init(); for voice in engine.getProperty('voices'): print(voice.id)
VOICE_INDEX = 1 # Defaulting to 1 (often a female voice)
SPEECH_RATE = 170 # Adjust as needed (default is usually 200)
SPEECH_VOLUME = 1.0 # 0.0 to 1.0

# --- Global Engine Initialization (Efficient) ---
# Initialize the engine once globally to avoid re-initialization overhead
try:
    # Try 'sapi5' for Windows, 'espeak' for Linux/macOS
    if sys.platform == "win32":
        engine = pyttsx3.init("sapi5")
    else:
        engine = pyttsx3.init("espeak")
    
    voices = engine.getProperty('voices')
    if VOICE_INDEX < len(voices):
        engine.setProperty('voice', voices[VOICE_INDEX].id)
    else:
        print(f"Warning: Voice index {VOICE_INDEX} out of range. Using default voice.")
    
    engine.setProperty('rate', SPEECH_RATE)
    engine.setProperty('volume', SPEECH_VOLUME)
except Exception as e:
    print(f"Error initializing text-to-speech engine: {e}")
    print("Please ensure pyttsx3 backend (e.g., sapi5 for Windows, espeak for Linux) is properly installed.")
    sys.exit(1) # Exit if TTS engine cannot be initialized

def speak(text):
    """Converts text to speech using the initialized engine."""
    global engine # Access the globally initialized engine
    try:
        print(f"{ASSISTANT_NAME}: {text}") # Print what the assistant says
        engine.say(text)
        engine.runAndWait()
    except Exception as e:
        print(f"Error during speech output: {e}")

def command():
    """Listens for a command from the microphone and returns it as a string."""
    r = sr.Recognizer()
    with sr.Microphone() as source:
        r.adjust_for_ambient_noise(source, duration=0.7) # Slightly longer adjustment
        print("Listening.....", end="", flush=True)
        r.pause_threshold = 0.8 # Reduced pause threshold for quicker recognition
        r.phrase_threshold = 0.3
        r.sample_rate = 48000
        r.dynamic_energy_threshold = True
        # r.operation_timeout = 5 # Removed as it can sometimes cause issues
        r.non_speaking_duration = 0.6 # Reduced non-speaking duration
        r.energy_threshold = 4000
        r.phrase_time_limit = 8 # Reduced phrase time limit for conciseness
        try:
            audio = r.listen(source, timeout=5, phrase_time_limit=8) # Added timeout
        except sr.WaitTimeoutError:
            print("\rNo speech detected within timeout. Trying again.")
            return "none"
        except Exception as e:
            print(f"\rMicrophone error: {e}")
            return "none"

    try:
        print("\r", end="", flush=True)
        print("Recognizing.......", end="", flush=True)
        query = r.recognize_google(audio, language='en-in')
        print(f"\r{USER_NAME} said: {query}\n", end="")
        return query
    except sr.UnknownValueError:
        print("\rSorry, I could not understand what you said. Please try again.")
        return "none"
    except sr.RequestError as e:
        print(f"\rCould not request results from Google Speech Recognition service; {e}")
        return "none"
    except Exception as e:
        print(f"\rAn unexpected error occurred during recognition: {e}")
        return "none"


def cal_day():
    """Calculates and returns the current day of the week."""
    day = datetime.datetime.today().weekday() + 1
    day_dict = {
        1: "Monday", # Corrected Monday for weekday() starting at 0
        2: "Tuesday",
        3: "Wednesday",
        4: "Thursday",
        5: "Friday",
        6: "Saturday",
        7: "Sunday"
    }
    return day_dict.get(day, "Unknown Day")


def wishMe():
    """Greets the user based on the time of day, current day, and time."""
    hour = datetime.datetime.now().hour
    t = time.strftime("%I:%M:%p")
    day = cal_day()

    if 0 <= hour < 12:
        speak(f"Good morning {USER_NAME}, It's {day} and the time is {t}")
    elif 12 <= hour < 18:
        speak(f"Good Afternoon {USER_NAME}, It's {day} and the time is {t}")
    else:
        speak(f"Good Evening {USER_NAME}, It's {day} and the time is {t}")


def social_media(query):
    """Opens specified social media platforms."""
    if 'facebook' in query:
        speak("Opening your Facebook account")
        webbrowser.open("http://www.facebook.com/")
    elif 'whatsapp' in query:
        speak("Opening your WhatsApp account")
        webbrowser.open("https://web.whatsapp.com/")
    elif 'discord' in query:
        speak("Opening your Discord server")
        webbrowser.open("https://discord.com")
    elif 'instagram' in query:
        speak("Opening your Instagram account")
        webbrowser.open("https://www.instagram.com/")
    else:
        speak("Sorry, I can only open Facebook, WhatsApp, Discord, or Instagram at the moment.")


def schedule():
    """Announces today's university schedule."""
    day = cal_day()
    speak(f"{USER_NAME}, today's schedule is:")
    week_schedule = {
        "Monday": "Starts from 9:00 AM. First, you have Object Oriented Programming, followed by Discrete Mathematics.",
        "Tuesday": "Starts from 10:00 AM. First, you have Data Structures, followed by Computer Networks.",
        "Wednesday": "Starts from 9:30 AM. First, you have Database Management Systems, followed by Operating Systems.",
        "Thursday": "Starts from 11:00 AM. First, you have Software Engineering, followed by Artificial Intelligence.",
        "Friday": "Starts from 9:00 AM. You have a project meeting, followed by a seminar on new technologies.",
        "Saturday": "It's a non-working day for classes. You might have personal study or extra-curricular activities.",
        "Sunday": "It's a holiday. Enjoy your day!"
    }
    
    speak(week_schedule.get(day, "I don't have a specific schedule for today."))


def openApp(query):
    """Opens specified system applications."""
    app_name = ""
    app_path = ""

    if "calculator" in query:
        app_name = "calculator"
        if sys.platform == "win32":
            app_path = 'calc.exe' # Windows can often find these by name
        elif sys.platform == "darwin": # macOS
            app_path = 'open /Applications/Calculator.app'
        else: # Linux
            app_path = 'gnome-calculator' # Or kcalc, xcalc etc.
    elif "notepad" in query:
        app_name = "notepad"
        if sys.platform == "win32":
            app_path = 'notepad.exe'
        elif sys.platform == "darwin":
            app_path = 'open /Applications/TextEdit.app'
        else:
            app_path = 'gedit' # Or kate, nano etc.
    elif "paint" in query:
        app_name = "paint"
        if sys.platform == "win32":
            app_path = 'mspaint.exe'
        elif sys.platform == "darwin":
            app_path = 'open /System/Applications/Preview.app' # macOS doesn't have direct Paint
        else:
            app_path = 'pinta' # Or kolourpaint, gimp etc.

    if app_path:
        speak(f"Opening {app_name}")
        try:
            if sys.platform == "win32":
                os.startfile(app_path) # Simplified for Windows
            else:
                os.system(app_path) # For macOS/Linux commands
        except Exception as e:
            speak(f"Could not open {app_name}. Error: {e}")
            print(f"Error opening app: {e}")
    else:
        speak(f"Sorry, I don't know how to open that application on your operating system.")


def closeApp(query):
    """Closes specified system applications."""
    app_to_kill = ""
    if "calculator" in query:
        app_to_kill = "calc.exe"
    elif "notepad" in query:
        app_to_kill = "notepad.exe"
    elif "paint" in query:
        app_to_kill = "mspaint.exe"
    
    if app_to_kill:
        speak(f"Closing {app_to_kill.replace('.exe', '')}")
        try:
            if sys.platform == "win32":
                os.system(f'taskkill /f /im {app_to_kill}')
            else: # For Linux/macOS, process names might differ, or require killall
                # This is a very basic attempt and might need refinement for specific apps
                os.system(f'pkill {app_to_kill.split(".")[0]}') 
        except Exception as e:
            speak(f"Could not close {app_to_kill.replace('.exe', '')}. Error: {e}")
            print(f"Error closing app: {e}")
    else:
        speak("Sorry, I can only close Calculator, Notepad, or Paint.")


if __name__ == "__main__":
    wishMe()
    while True:
        query = command().lower()

        if query == "none":
            # Assistant didn't understand, or no speech was detected. Loop again.
            continue
        
        # --- Command Handling ---
        # Using if/elif structure for clarity, could be a dictionary for more complex scenarios
        
        # Social Media
        elif 'open facebook' in query or 'open whatsapp' in query or 'open discord' in query or 'open instagram' in query:
            social_media(query)
        
        # Schedule
        elif "university time table" in query or "show my schedule" in query or "what is my schedule today" in query:
            schedule()
            
        # Volume Control
        elif "volume up" in query or "increase volume" in query:
            pyautogui.press("volumeup")
            speak("Volume increased")
        elif "volume down" in query or "decrease volume" in query:
            pyautogui.press("volumedown")
            speak("Volume decreased")
        elif "volume mute" in query or "mute the sound" in query or "mute volume" in query:
            pyautogui.press("volumemute")
            speak("Volume muted")
            
        # Application Control
        elif "open calculator" in query or "open notepad" in query or "open paint" in query:
            openApp(query)
        elif "close calculator" in query or "close notepad" in query or "close paint" in query:
            closeApp(query)
            
        # Exit Command
        elif "exit" in query or "quit" in query or "goodbye" in query:
            speak(f"Goodbye {USER_NAME}! Have a great day.")
            sys.exit()
            
        else:
            speak("Sorry, I didn't understand that command. Can you please repeat?")